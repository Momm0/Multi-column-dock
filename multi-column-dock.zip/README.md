# Multi-column-dock
A novel multi-column dock for GNOME Shell.
